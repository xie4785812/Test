package com.hermes.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "RemovedUser", schema = "hermes")
public class RemovedUserEntity {
    private int id;
    private String userId;
    private String cellPhone;
    private String name;
    private String email;
    private String department;

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Basic
    @Column(name = "userId")
    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    @Basic
    @Column(name = "cellPhone")
    public String getCellPhone() {
        return cellPhone;
    }

    public void setCellPhone(String cellPhone) {
        this.cellPhone = cellPhone;
    }

    @Basic
    @Column(name = "name")
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Basic
    @Column(name = "email")
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Basic
    @Column(name = "department")
    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public RemovedUserEntity() {
    }

    public RemovedUserEntity(userInfo user) {
        this.userId = user.getUserId();
        this.name = user.getName();
        this.cellPhone = user.getCellphone();
        this.department = user.getDepartment();
        this.email = user.getEmail();
    }

}
