package com.hermes.entity;

public class MessageResponse {
    private int responsCode;
    private String responsStatus;
    private String receiveTime;
    private RiskMessageEntity message;
}
