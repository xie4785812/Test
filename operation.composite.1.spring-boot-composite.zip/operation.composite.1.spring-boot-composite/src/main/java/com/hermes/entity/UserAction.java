package com.hermes.entity;

import javax.persistence.*;

@Entity
@Table(name = "UserAction", schema = "hermes")
public class UserAction {
    private int id;
    private String userId;
    private String name;
    private int actionType;
    private String action;
    private String actionTime;

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Basic
    @Column(name = "userId")
    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    @Basic
    @Column(name = "name")
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Basic
    @Column(name = "actionType")
    public int getActionType() {
        return actionType;
    }

    public void setActionType(int actionType) {
        this.actionType = actionType;
    }

    @Basic
    @Column(name = "action")
    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    @Basic
    @Column(name = "actionTime")
    public String getActionTime() {
        return actionTime;
    }

    public void setActionTime(String actionTime) {
        this.actionTime = actionTime;
    }

    public UserAction() {
    }

    public UserAction(String userId, String name, int actionType, String action, String actionTime) {
        this.userId = userId;
        this.name = name;
        this.actionType = actionType;
        this.action = action;
        this.actionTime = actionTime;
    }
}
