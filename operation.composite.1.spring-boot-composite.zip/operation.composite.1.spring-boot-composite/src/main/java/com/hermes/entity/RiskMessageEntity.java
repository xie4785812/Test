package com.hermes.entity;

public class RiskMessageEntity {
    private String id;
    private String content;
    private String deliveryTime;
    private String receivedTime;
    private String status;
    private String responseTime;
    private String sendTime;
    private String receiver;
}
