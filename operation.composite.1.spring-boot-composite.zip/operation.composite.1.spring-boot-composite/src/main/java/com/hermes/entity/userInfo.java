package com.hermes.entity;


import javax.persistence.*;

@Entity
@Table(name = "userInfo", schema = "hermes")
public class userInfo {
    private int id;
    private String userId;
    private String name;
    private String cellphone;
    private String email;
    private String department;

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int getId(){
        return id;
    }

    public void setId(int id){
        this.id = id;
    }

    @Basic
    @Column(name = "userId")
    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    @Basic
    @Column(name = "name")
    public String getName(){
        return name;
    }

    public void setName(String name){
        this.name = name;
    }

    @Basic
    @Column(name = "cellphone")
    public String getCellphone(){
        return cellphone;
    }

    public void setCellphone(String cellphone){
        this.cellphone = cellphone;
    }

    @Basic
    @Column(name = "email")
    public String getEmail(){
        return email;
    }

    public void setEmail(String email){
        this.email = email;
    }

    @Basic
    @Column(name = "department")
    public String getDepartment(){
        return department;
    }

    public void setDepartment(String department){
        this.department = department;
    }


}
