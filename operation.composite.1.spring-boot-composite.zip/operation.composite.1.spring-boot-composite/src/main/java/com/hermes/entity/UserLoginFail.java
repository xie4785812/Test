package com.hermes.entity;


import javax.persistence.*;

@Entity
@Table(name = "UserLoginFail", schema = "hermes")
public class UserLoginFail {
    private int id;
    private String userId;
    private String times;

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int getId(){return id;}

    public void setId(int id) {
        this.id = id;
    }

    @Basic
    @Column(name = "userId")
    public String getUserId() {
        return userId;
    }


    public void setUserId(String userId) {
        this.userId = userId;
    }

    @Basic
    @Column(name = "times")
    public String getTimes() {
        return times;
    }

    public void setTimes(String times) {
        this.times = times;
    }
}
