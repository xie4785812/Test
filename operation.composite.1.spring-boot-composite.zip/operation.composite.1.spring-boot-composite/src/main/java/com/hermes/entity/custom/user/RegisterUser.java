package com.hermes.entity.custom.user;

public class RegisterUser {
    public String userId;
    public String password;
}
