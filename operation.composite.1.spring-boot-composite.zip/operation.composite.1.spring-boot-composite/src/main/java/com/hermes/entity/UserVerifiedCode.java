package com.hermes.entity;

import javax.persistence.*;

@Entity
@Table(name = "UserVerifiedCode", schema = "hermes", catalog = "")
public class UserVerifiedCode {
    private String userId;
    private String code;
    private String time;

    public UserVerifiedCode() {
    }

    public UserVerifiedCode(String userId, String code, String time) {
        this.userId = userId;
        this.code = code;
        this.time = time;
    }

    @Id
    @Column(name = "userId")
    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    @Basic
    @Column(name = "code")
    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    @Basic
    @Column(name = "time")
    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }
}
