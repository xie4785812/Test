package com.hermes.entity;

public class ActionType {
    public static final short LOGIN=0, DOWNLOAD=1, OAUSERMANAGE=2, IBUSERMANAGE=3, RESTOREUSER=4, FILEMANAGE=5,
            MAINSTEPMANAGE=6, SUBSTEPMANAGE=7, BUSINESSMANAGE=8;
}
