package com.hermes.config;

import com.hermes.entity.*;
import com.hermes.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {

    @Autowired
    UserRoleRespository userRoleRepository;

    @Autowired
    UserActionRepository userActionRepository;

    @Autowired
    RemovedUserRepository removedUserRepository;

    @Autowired
    UserVerifiedCodeRepository userVerifiedCodeRepository;

    @Autowired
    UserLoginFailRepository userLoginFailureRepository;

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.cors()
                .and()
                .csrf().disable()
                .authorizeRequests()
                .antMatchers(HttpMethod.POST, "/user").permitAll()
                .antMatchers(HttpMethod.GET, "/user/verify").permitAll()
                .antMatchers(HttpMethod.POST,"/business/mystep").permitAll()
                .anyRequest().authenticated()
                .and()
                .addFilter(new com.hermes.config.JwtAuthenticationFilter(authenticationManager()))
                .addFilter(new com.hermes.config.JwtAuthorizationFilter(authenticationManager()))
                .sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS);
    }

    @Bean
    @Override
    protected UserDetailsService userDetailsService() {
        return new UserDetailsService() {
            @Override
            public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
                SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd 00:00:00");
                Date datex = new Date(System.currentTimeMillis());
                String currentDate = formatter.format(datex);

//                remove all the failure records before current date
                List<UserLoginFail> userLoginFailures = userLoginFailureRepository.findByUserIdAndTimesLessThan(username, currentDate);
                userLoginFailureRepository.deleteAll(userLoginFailures);

//                if the total failure reach 5 times today, it should be prohibited from loggined the rest of the day.
                if (userLoginFailureRepository.findByUserIdAndTimesGreaterThanEqual(username, currentDate).size() >= 5) {
                    throw new UsernameNotFoundException(username + " not found!");
                }

                SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                Date date = new Date();
                UserAction userAction = new UserAction(
                        username,
                        "",
                        ActionType.LOGIN,
                        "", format.format(date));

                Optional<RemovedUserEntity> removedUserEntityOptional =
                        removedUserRepository.findByUserId(username);
                if (removedUserEntityOptional.isPresent()){
                    userAction.setAction("登录失败，用户已被删除！");
                    userActionRepository.save(userAction);

                    throw new UsernameNotFoundException(username + " not found!");
                }

                Optional<UserVerifiedCode> codeOptional = userVerifiedCodeRepository.findById(username);
                if (!codeOptional.isPresent()){
                    userAction.setAction("登录失败，用户验证码不存在！");
                    userActionRepository.save(userAction);

                    throw new UsernameNotFoundException(username + " not found!");
                }

//                Optional<UserVerifiedCode> timeOptional = userVerifiedCodeRepository.findById(username);

                String currentTime = codeOptional.get().getTime();
                userAction.setAction(currentTime);
                userActionRepository.save(userAction);


                UserVerifiedCode user = codeOptional.get();

                userAction.setAction("登录成功！");
                userActionRepository.save(userAction);

                synchronized (SecurityConfig.class){
                    userVerifiedCodeRepository.deleteById(username);
                }

                String role = "USER";
                Optional<UserEntity> userEntityOptional = userRoleRepository.findByUserId(username);
                if (userEntityOptional.isPresent()) {
                    role = userEntityOptional.get().getRole();
                }

                return User.withUsername(user.getUserId())
                        .password(passwordEncoder().encode(user.getCode()))
                        .roles(role)
                        .build();
            }
        };
    }

    @Bean
    public PasswordEncoder passwordEncoder(){
        return new BCryptPasswordEncoder();
    }

    @Bean
    public CorsConfigurationSource corsConfigurationSource(){
        CorsConfiguration corsConfiguration = new CorsConfiguration();

        corsConfiguration.setAllowedOrigins(Collections.singletonList("*"));
        corsConfiguration.setAllowedMethods(Collections.singletonList("*"));

        corsConfiguration.addExposedHeader("LoginFailed");
        corsConfiguration.addAllowedHeader("LoginFailed");
        corsConfiguration.addExposedHeader("authorization");
        corsConfiguration.addAllowedHeader("authorization");
        corsConfiguration.setAllowedHeaders(Collections.singletonList("*"));

        corsConfiguration.addExposedHeader("Content-Disposition");
        corsConfiguration.addAllowedHeader("Content-Disposition");

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", corsConfiguration);
        return source;
    }

}
