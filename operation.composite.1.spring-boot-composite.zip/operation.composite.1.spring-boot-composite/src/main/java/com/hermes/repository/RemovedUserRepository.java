package com.hermes.repository;

import com.hermes.entity.RemovedUserEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface RemovedUserRepository extends JpaRepository<RemovedUserEntity, Integer> {
    Optional<RemovedUserEntity> findByUserId(String userId);
}
