package com.hermes.repository;

import com.hermes.entity.UserVerifiedCode;
import com.hermes.entity.UserVerifiedCode;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserVerifiedCodeRepository extends JpaRepository<UserVerifiedCode, String> {
}
