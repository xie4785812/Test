package com.hermes.repository;

import com.hermes.entity.userInfo;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface UserRepository extends JpaRepository<userInfo, Integer> {
    Optional<userInfo> findByUserId(String userId);
    List<userInfo> findByUserIdAndCellphone(String userId, String cellphone);
}
