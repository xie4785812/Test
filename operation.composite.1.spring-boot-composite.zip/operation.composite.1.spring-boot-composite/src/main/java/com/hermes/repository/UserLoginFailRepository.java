package com.hermes.repository;

import com.hermes.entity.UserLoginFail;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface UserLoginFailRepository extends JpaRepository<UserLoginFail, Integer> {
    List<UserLoginFail> findAllByUserId(String userId);

    List<UserLoginFail> findByUserIdAndTimesLessThan(String userId, String times);

    List<UserLoginFail> findByUserIdAndTimesGreaterThanEqual(String userId, String times);
}
