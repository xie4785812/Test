package com.hermes.controller;

import com.hermes.config.SMSProperties;
import com.hermes.entity.MessageResponse;
import com.hermes.entity.UserEntity;
import com.hermes.entity.UserVerifiedCode;
import com.hermes.entity.custom.FMResponse;
import com.hermes.entity.custom.user.RegisterUser;
import com.hermes.entity.userInfo;
import com.hermes.repository.UserLoginFailRepository;
import com.hermes.repository.UserRepository;
import com.hermes.repository.UserVerifiedCodeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Optional;
import java.util.Random;

enum LockObjs {
    VerificationCode, UpdateUser, RemoveUser
}

@RestController
public class UserController {
    @Autowired
    UserRepository userRepository;

    @Autowired
    UserLoginFailRepository userLoginFailRepository;

    @Autowired
    SMSProperties smsProperties;

    @Autowired
    RestTemplate restTemplate;

    @Autowired
    UserVerifiedCodeRepository userVerifiedCodeRepository;

//    @PostMapping("/user")
//    public void registerUser(@RequestBody RegisterUser user){
//        // 生成新对象
//        UserEntity userEntity = new UserEntity();
//        // 为生成的新对象设置ID和密码
//        userEntity.setUserId(user.userId);
//        // 密码转码
//        userEntity.setPassword(passwordEncoder.encode(user.password));
//
//        //存储在数据库中
//        userRepository.save(userEntity);
//    }


    @GetMapping("/user/verify")
    public FMResponse getVerify(@RequestParam("userId") String userId){
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd 00:00:00");
        Date nowTime = new Date(System.currentTimeMillis());
        String currentDate = dateFormat.format(nowTime);

        if(userLoginFailRepository.findByUserIdAndTimesGreaterThanEqual(userId, currentDate).size() >= 100){
            return new FMResponse(-1,"您已登录失败超过5次，请明天再试！",null);
        }

        Optional<userInfo> userInfoOptional = userRepository.findByUserId(userId);
        String cellphone = "";
        if (userInfoOptional.isPresent()){
            cellphone = userInfoOptional.get().getCellphone();
        }
        if(cellphone.isEmpty()){
            return new FMResponse(-2,"用户不存在或输入错误，请联系综合服务部",userId);
        }

        String verifiedCode = String.format("%06d", new Random().nextInt(999999));
//
//        // 生成一个url
//        String url = String.format("%s:%s/%s?msgId={msgId}&msgContent={msgContent}&receiver={receiver}&sentTime={sentTime}",
//                smsProperties.getHost(), smsProperties.getPort(), smsProperties.getUri());
////        String url = "http://10.21.2.65:8088/message?msgId={msgId}&msgContent={msgContent}&receiver={receiver}&sentTime={sentTime}";
//
        synchronized (LockObjs.VerificationCode){
//            MessageResponse messageResponse = restTemplate.getForObject(url,
//                    MessageResponse.class, "8", verifiedCode + " FormMaster验证码。", "19867723080", "");
            dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            nowTime = new Date(System.currentTimeMillis() + 1000*60*5);

            currentDate = dateFormat.format(nowTime);
            userVerifiedCodeRepository.save(new UserVerifiedCode("111", "123456", currentDate));
        }

        return new FMResponse(1, "验证码发送成功",null);
    }
}
