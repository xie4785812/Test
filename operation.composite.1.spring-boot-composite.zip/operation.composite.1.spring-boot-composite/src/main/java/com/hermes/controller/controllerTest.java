//package com.hermes.controller;
//
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//@RestController
//public class controllerTest {
//
//    @RequestMapping(path = {"/helloSpringBoot"})
//    public String HelloSpring (){
//        System.out.println("hello spring boot");
//        return "hello spring boot";
//    }
//}
